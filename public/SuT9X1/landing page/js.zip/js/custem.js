/*global $, alert, console*/

$(function(){
	
	$(window).width(function(){
		console.log($(this).width());
	});
	
	
		
	
	
});