$document.ready(function () {
    'use strict';
    $("p").click(function () {
        $(this).hide();
    });
});