<?php
$File = "db.ts";
$Handle = fopen($File, 'w');
$Data = "Welcome ..\n";
fwrite($Handle, $Data);
print "Data Earse";
fclose($Handle);
?>