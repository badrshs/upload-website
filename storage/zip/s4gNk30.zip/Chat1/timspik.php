<?
require_once('config.php');

if (!auth()) 
	{
	header('WWW-Authenticate: Basic realm="Priv8 Area"');
	header('HTTP/1.0 401 Unauthorized');
	echo 'Unauthorized';
	exit;
	}
else
	{	
	$nick=addslashes(htmlspecialchars($_POST['nick']));
	$msg=addslashes(htmlspecialchars($_POST['msg']));
	
	$db='db.ts';
	$chat=''; 
	$cfile='';
	$plik=fopen($db,"a+");
	
	if(filesize($db)>$history)
		{
		while(!feof($plik))$cfile.=fgets($plik,2048);
		fclose($plik); 
		$plik=fopen($db,"w");
		$cfile="...".substr($cfile,-(round($history*0.75)));
		fputs($plik,$cfile);
		fclose($plik);
		
		$plik=fopen($db,"a+");
		}
	
	
	if($nick!='refresh')
		{
		$findAllowed=array();
		$replAllowed=array();
		foreach($allowedTags as $tag)
			{
			$findAllowed[]="&lt;".$tag."&gt;";
			$findAllowed[]="&lt;/".$tag."&gt;";
			$findAllowed[]="&lt;".$tag."/&gt;";
			$replAllowed[]="<".$tag.">";
			$replAllowed[]="</".$tag.">";
			$replAllowed[]="<".$tag."/>";
			}
		$msg=str_replace($findAllowed,$replAllowed,$msg);
		
		$emotyIn=array("A0","A1","A3",
		               "A4","A5","A6","A7","A8","A9","A10","A11","A12","A13","A14","A15","A16","A17","A18","A19",
					   "A20","A21","A22","A23","A24","A25","A26","A27","A28","A29","A30",
					   "A31","A32","A33","A34","A3A","A36","A37","A38","A39","A40",
					   "A41","A42","A43","A44","A45","A46","A47","A48","A49","A50",
					   "A51","A52","A53","A54","A55","A56","A57","A58","A59","A60",
					   "A61","A62","A63","A64","A65","A66","A67","A68","A69","A70",
					   "A71","A72","A73","A74","A75","A76","A77","A78","A79","A80",
					   "A81","A82","A83","A84","A85","A86","A87","A88","A89","A90",
					   "A91","A92","A93","A94","A95","A96","A97","A98","A9A",
						);
		$emotyOut=array("<img src='emo/smile.gif'/>","<img src='emo/01.gif'/>","<img src='emo/03.gif'/>",
                        "<img src='emo/04.gif'/>","<img src='emo/05.gif'/>","<img src='emo/07.gif'/>","<img src='emo/08.gif'/>","<img src='emo/11.gif'/>","<img src='emo/12.gif'/>","<img src='emo/14.gif'/>","<img src='emo/15.gif'/>","<img src='emo/16.gif'/>",
	                    "<img src='emo/17.gif'/>","<img src='emo/18.gif'/>","<img src='emo/19.gif'/>","<img src='emo/20.gif'/>","<img src='emo/21.gif'/>","<img src='emo/22.gif'/>","<img src='emo/biggrin.gif'/>","<img src='emo/confused.gif'/>","<img src='emo/cool.gif'/>",

"<img src='emo/eek.gif'/>",

"<img src='emo/evil.gif'/>",

"<img src='emo/frown.gif'/>",

"<img src='emo/md.gif'/>",

"<img src='emo/m21.gif'/>",

"<img src='emo/oo.gif'/>",

"<img src='emo/oo2.gif'/>",

"<img src='emo/oo4.gif'/>",

"<img src='emo/oo7.gif'/>",

"<img src='emo/oo16.gif'/>",

"<img src='emo/oo14.gif'/>",

"<img src='emo/oo9.gif'/>",

"<img src='emo/oo10.gif'/>",

"<img src='emo/oo12.gif'/>",

"<img src='emo/oo17.gif'/>",

"<img src='emo/oo18.gif'/>",

"<img src='emo/oo19.gif'/>",

"<img src='emo/oo21.gif'/>",

"<img src='emo/oo23.gif'/>",

"<img src='emo/oo24.gif'/>",

"<img src='emo/oo25.gif'/>",

"<img src='emo/oo26.gif'/>",

"<img src='emo/oo27.gif'/>",

"<img src='emo/oo28.gif'/>",

"<img src='emo/oo33.gif'/>",

"<img src='emo/q.gif'/>",

"<img src='emo/redfce.gif'/>",

"<img src='emo/rolleyes.gif'/>",

"<img src='emo/sml1.gif'/>",

"<img src='emo/sml2.gif'/>",

"<img src='emo/sml3.gif'/>",

"<img src='emo/sml4.gif'/>",

"<img src='emo/sml5.gif'/>",

"<img src='emo/sml6.gif'/>",

"<img src='emo/sml7.gif'/>",

"<img src='emo/sml10.gif'/>",

"<img src='emo/sml11.gif'/>",

"<img src='emo/sml12.gif'/>",

"<img src='emo/sml14.gif'/>",


"<img src='emo/sml16.gif'/>",

"<img src='emo/sml20.gif'/>",

"<img src='emo/sml21.gif'/>",

"<img src='emo/sml22.gif'/>",

"<img src='emo/sml23.gif'/>",


"<img src='emo/sml24.gif'/>",

"<img src='emo/sml25.gif'/>",

"<img src='emo/sml26.gif'/>",

"<img src='emo/sml28.gif'/>",

"<img src='emo/sml29.gif'/>",


"<img src='emo/sml30.gif'/>",

"<img src='emo/sml34.gif'/>",

"<img src='emo/sml35.gif'/>",

"<img src='emo/sml38.gif'/>",

"<img src='emo/sml39.gif'/>",
	
"<img src='emo/sml40.gif'/>",

"<img src='emo/sml41.gif'/>",

"<img src='emo/sml71.gif'/>",

"<img src='emo/sml79.gif'/>",

"<img src='emo/sml80.gif'/>",

	
	
"<img src='emo/sml86.gif'/>",

"<img src='emo/smll3.gif'/>",

"<img src='emo/smll6.gif'/>",

"<img src='emo/smll11.gif'/>",

"<img src='emo/smll15.gif'/>",


"<img src='emo/smll16.gif'/>",

"<img src='emo/smll19.gif'/>",

"<img src='emo/smll20.gif'/>",

"<img src='emo/smll21.gif'/>",

"<img src='emo/smll22.gif'/>",


"<img src='emo/smll34.gif'/>",

"<img src='emo/smll57.gif'/>",

"<img src='emo/smll80.gif'/>",

"<img src='emo/smll82.gif'/>",

"<img src='emo/smll86.gif'/>",

"<img src='emo/smll89.gif'/>",

"<img src='emo/smll91.gif'/>",

"<img src='emo/tongue.gif'/>",

"<img src='emo/wink.gif'/>"

						);
		$msg=str_replace($emotyIn,$emotyOut,$msg);
		fputs($plik,"<p><em>".date("H:i:s")." &lt;".$nick."&gt;</em> ".$msg."</p>");
		}
		
	rewind($plik);
	while(!feof($plik))	$chat.=fgets($plik,2048);
	fclose($plik);
	echo $chat;
	}
?>