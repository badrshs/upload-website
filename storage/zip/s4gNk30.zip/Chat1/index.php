<?
require_once('config.php');

if (!auth()) 
	{
	header('WWW-Authenticate: Basic realm="Priv8 Area"');
	header('HTTP/1.0 401 Unauthorized');
	echo 'Unauthorized to Chat';
	exit;
	}
else {	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?=$ver;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="j.js"></script>
<script type="text/javascript" src="t.js"></script>
<link href="tareq.css" rel="stylesheet" type="text/css" />
</head>
<body>
<h2 align="center">&nbsp;&nbsp;:: Security - Codes Chat :: by <a href="http://www.sec-code.com/" target="_blank">Security - Codes TeaM</a></h2>
<div align="center">
<table border="1" width="150" height="60">
<tr>
<td width="150" height="60" align="center">
<p align="center"><a href="www.wire4host.com" target="_blank"><img border="0" src="http://www.sec-code.com/vb/WIRE4HOST.gif" width="150" height="60"></a></p>
</td>
<td width="150" height="60" align="center">
<p align="center"><a href="www.arabia23.com" target="_blank"><img border="0" src="http://www.arabia23.com/advs/%5Barabia23.com%5D_160-60.jpg" width="150" height="60"></a></p>
</td>
<td width="150" height="60" valign="middle" align="center">
<p align="center"><a href="www.up-ar.com" target="_blank"><img border="0" src="http://www.up-ar.com/styles/tr-v2/images/adv.gif" width="150" height="60"></a></p>
</td>
</tr>
</table>
</div>
<div id="output"><b class="date"><?=date("H:i:s");?></b></div>
<form action="" method="post" onsubmit="return say();">
Nickname: <input type="text" name="nick" value="nick" id="nick" /><br>
                  <td width="155" height="2" bgcolor="#FFFFFF" align="right">
<input type="text" name="message" value="Write Here" id="message" />
<input type="submit" name="submit" value="Post!" id="submit" />
<script type="text/javascript">
function AddSmile(SmileCode) {
var message = window.document.getElementById("message");
message.value += SmileCode;
message.focus();
return;
}
</script>

<table border="1" class="smiley" width="118">
		</td>
		<td>
		<p align="center"><img src="emo/01.gif" alt="" onclick="AddSmile('A1')" />
		</td>
		<td width="81">
		<p align="center"><img src="emo/03.gif" alt="" onclick="AddSmile('A3')" />
		</td>
		<td width="80">
		<p align="center"><img src="emo/04.gif" alt="" onclick="AddSmile('A4')" />
		</td>
		<td width="81">
		<p align="center">
		<img src="emo/07.gif" alt="" onclick="AddSmile('A6')" /></td>
		<td width="81">
		<p align="center"><img src="emo/11.gif" alt="" onclick="AddSmile('A8')" /></td>
		<td width="81">
		<p align="center"><img src="emo/12.gif" alt="" onclick="AddSmile('A9')" /></td>
		<td width="81">
		<p align="center"><img src="emo/05.gif" alt="" onclick="AddSmile('A5')" />
		</td>
	</tr>
	</table>

<br><br>
Refresh rate (seconds) <input type="text" value="30" id="refresh" name="refresh" maxlength="2"/><br>
Window width: <input type="text" value="500" id="width" name="width" maxlength="3"/>
Window height: <input type="text" value="330" id="height" name="height" maxlength="3"/>
</form>
<div id="footnote">Developed By <a href="http://sec-code.com" target="_blank">RoMaNcYxHaCkEr</a></div>
</body>
</html>
<? } ?>