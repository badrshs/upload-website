<?
//require authorisation
define("REQUIRE_AUTH",false);

//if authorisation required, define users here
$users=array();
$users[]=array("rxh","000000");


//allowed html tags
$allowedTags=array("b","i","br","u");

//maximum history size (bytes)
$history=4096;

//app version / title
$ver=":: Security - Codes Chat ::";



//basic auth function
function auth()
{
if(REQUIRE_AUTH) {
	global $users;
	foreach($users as $auth)if($auth[0]==$_SERVER['PHP_AUTH_USER']&&$auth[1]==$_SERVER['PHP_AUTH_PW'])return true;
	return false;	
	}
else return !REQUIRE_AUTH;
}
?>