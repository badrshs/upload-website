<?

   $file = fopen("count.txt","r+");
   $count = fread($file, filesize("count.txt"));
   fclose($file);
   $count+=1;
   $file = fopen("count.txt","w");
   fputs($file,$count );
   fclose($file);
   echo "$count";

?>